from cms.plugin_base import CMSPluginBase
from cms.plugin_pool import plugin_pool
from cms.models.pluginmodel import CMSPlugin
from django.utils.translation import gettext_lazy as _

from .models import Nothing

@plugin_pool.register_plugin
class nothingPlugin(CMSPluginBase):
    model = Nothing
    render_template = "nothing.html"
    cache = False

    #def render(self, context, instance, placeholder):
       # context = super().render(context, instance, placeholder)
        #return context
