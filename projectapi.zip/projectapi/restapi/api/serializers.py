from rest_framework import serializers
from .models import Books

class BookSerializers(serializers.ModelSerializer):
    class Meta:
        model = Books
        fields = '__all__'

        def validate_page(self,num):
            if num <= 0:
                raise serializers.ValidationError("Number of the pages have to bigger than zero!")
            return num
