from django.urls import path
from . import views

urlpatterns = [
    path('addbook/', views.AddBook.as_view(), name="addbook"),
    path('updatebook/<int:pk>/', views.UpdateBook.as_view(), name="updatebook"),
]
