from django.shortcuts import render
from rest_framework.generics import ListCreateAPIView, RetrieveUpdateDestroyAPIView
from .serializers import BookSerializers
from .models import Books

class AddBook(ListCreateAPIView):
    queryset = Books.objects.all()
    serializer_class = BookSerializers

class UpdateBook(RetrieveUpdateDestroyAPIView):
    queryset = Books.objects.all()
    serializer_class = BookSerializers


