from django.db import models

# Create your models here.

class Books(models.Model):
    book = models.CharField(max_length=200)
    author = models.CharField(max_length=100)
    page = models.IntegerField()

    def __str__(self):
        return self.book